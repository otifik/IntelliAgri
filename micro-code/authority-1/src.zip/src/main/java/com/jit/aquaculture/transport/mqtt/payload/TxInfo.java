package com.jit.aquaculture.transport.mqtt.payload;

import lombok.Data;

/**
 * @packageName: xxz.vegetables.entry
 * @className: TxInfo
 * @Description:
 * @author: xxz
 * @date: 2019/12/19 13:01
 */

@Data
public class TxInfo {
    int frequency;
    int dr;
}

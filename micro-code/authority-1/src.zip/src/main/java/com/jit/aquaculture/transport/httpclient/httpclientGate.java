package com.jit.aquaculture.transport.httpclient;


public class httpclientGate {


}

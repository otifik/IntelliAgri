package com.jit.aquaculture.responseResult.result;

import java.io.Serializable;

/**
 * 响应格式父接口
 */
public interface Result extends Serializable {

}

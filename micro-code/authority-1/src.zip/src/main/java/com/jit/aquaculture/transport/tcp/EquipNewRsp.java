package com.jit.aquaculture.transport.tcp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @className: ReportData
 * @author: kay
 * @date: 2019/7/22 14:59
 * @packageName: com.jit.iot.utils
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EquipNewRsp {
    public String name;//传感器名称
    public String type;//传感器类型
    public int value;  //0:关闭 或者 1:打开
}

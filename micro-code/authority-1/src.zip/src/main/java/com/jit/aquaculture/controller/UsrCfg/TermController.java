package com.jit.aquaculture.controller.UsrCfg;

import com.jit.aquaculture.commons.pages.PageQO;
import com.jit.aquaculture.commons.pages.PageVO;
import com.jit.aquaculture.config.iot.SensorCmdCfg;
import com.jit.aquaculture.config.iot.TermType;
import com.jit.aquaculture.domain.iot.TermDO;
import com.jit.aquaculture.responseResult.result.ResponseResult;
import com.jit.aquaculture.serviceimpl.iot.custom.SensorDefServiceImpl;
import com.jit.aquaculture.serviceimpl.iot.custom.TerminalServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @packageName: com.jit.iot.controller
 * @className: TermController
 * @author: xxz
 * @date: 2019/7/25 10:05
 */

@Slf4j
@RestController
@CrossOrigin
@RequestMapping(value = "/termdef")
@Api(description = "终端配置")
@ResponseResult
public class TermController {
    @Resource
    TerminalServiceImpl termService;
    @Autowired
    SensorCmdCfg cmdCfg;
    @Autowired
    SensorDefServiceImpl sensorDefService;

    //用户新增终端
    @ApiOperation(value = "新增自定义终端" ,  notes="新增终端")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/addDefTerm", method = RequestMethod.POST)
    public TermDO addTerm(@RequestParam(value = "type") int type,
                          @RequestParam(value = "name") String name,
                          @RequestParam(value = "user") String user
                           ) throws Exception{
        return termService.addTerm(type, null, name, user);
    }


    //用户新增终端
    @ApiOperation(value = "新增固定式终端" ,  notes="新增终端")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/addFixTerm", method = RequestMethod.POST)
    public TermDO addTerm(
        @RequestParam(value = "type") int type,
        @RequestParam(value = "deveui") String deveui,
        @RequestParam(value = "manu") String manu,
        @RequestParam(value = "prod") String prod,
        @RequestParam(value = "cellid") int cellid,
        @RequestParam(value = "name") String name,
        @RequestParam(value = "user") String user
                           ) throws Exception {
        TermDO term = null;


        switch (type) {
            case 2:
                term = termService.addTerm(type, deveui, name, user);
                //固定式终端的传感器无需配置直接添加
                if (term != null) {
                    sensorDefService.addSensor(cellid, term.getId(), manu+"_"+prod, 1, name);
                }
                break;
            case 3:
                term = termService.addTerm(type, deveui, name, user);
                //农芯传感器终端包含温度、湿度、光照、Co2、土壤温度、土壤湿度
                if (term != null) {
                    sensorDefService.addSensor(cellid, term.getId(), manu+"_"+prod, 401, name);
//                    sensorDefService.addSensor(cellid, term.getId(), "NX_AIR_HUMI", 0, name + "_湿度");
//                    sensorDefService.addSensor(cellid, term.getId(), "NX_SOIL_TEMP", 0, name + "_土壤温度");
//                    sensorDefService.addSensor(cellid, term.getId(), "NX_SOIL_HUMI", 0, name + "_土壤湿度");
//                    sensorDefService.addSensor(cellid, term.getId(), "NX_CO2", 0,  name + "_C02");
//                    sensorDefService.addSensor(cellid, term.getId(), "NX_ILLU", 0, name + "_光照");
                }
                break;
            default:
                log.info("新增终端类型{}unkown", type);
                break;
        }
        return term;
    }

    //查询终端类型
    @ApiOperation(value = "查询所有终端厂家" ,  notes="列出系统内所有终端的生产厂家")
    @RequestMapping(value = "/listTermManus", method = RequestMethod.GET)
    public List<String> listTermManus() {
        return cmdCfg.getManus();
    }


    //查询终端类型
    @ApiOperation(value = "查询某终端厂家下所有产品" ,  notes="列出终端厂家的所有终端产品")
    @RequestMapping(value = "/listManuProducts", method = RequestMethod.GET)
    public List<String> listManuProducts( @RequestParam(value = "manu") String manu) {
        return cmdCfg.getManuProducts(manu);
    }


    //列出所有终端及登录状态
    @ApiOperation(value = "查询所有终端" ,  notes="列出系统内所有终端")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/listAllTerms", method = RequestMethod.GET)
    public PageVO<TermDO> listAllTerms(PageQO pageQO) {
        return termService.listAllTerms(pageQO);
    }


    //列出某个用户所有终端及登录状态
    @ApiOperation(value = "查询用户的终端" ,  notes="列出用户的所有终端")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/listTermsByUsr", method = RequestMethod.GET)
    public PageVO<TermDO> listTermsByUsr(@RequestParam(value = "user_name") String user_name, PageQO pageQO) {
        return termService.listTermsByUsr(pageQO,user_name);
    }
}

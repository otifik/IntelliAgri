package com.jit.aquaculture.config.iot;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EquipType {
    String type;
}

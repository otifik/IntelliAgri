package com.jit.aquaculture.controller.user;


import com.github.pagehelper.PageInfo;
import com.jit.aquaculture.commons.pages.PageQO;
import com.jit.aquaculture.commons.pages.PageVO;
import com.jit.aquaculture.domain.daily.DailyThrow;
import com.jit.aquaculture.domain.user.Role;
import com.jit.aquaculture.domain.user.User;
import com.jit.aquaculture.domain.user.UserRole;
import com.jit.aquaculture.dto.ResetPassword;
import com.jit.aquaculture.dto.UserDto;
import com.jit.aquaculture.responseResult.result.ResponseResult;
import com.jit.aquaculture.serviceinterface.daily.DailyThrowService;
import com.jit.aquaculture.serviceinterface.user.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(value = "用户管理",description = "用户基本信息管理")
@RestController
@RequestMapping("user")
@ResponseResult
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private DailyThrowService dailyThrowService;
//
    /**
     * 管理员分页获取全部用户
     * @param pageNum 页码
     * @param pageSize 每页显示条数
     * @return 用户列表
     */
    @ApiOperation(value = "管理员或专家分页获取全部用户",notes = "分页获取全部用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "pageNum", value = "起始页码", required = false, dataType = "int"),
            @ApiImplicitParam(name="pageSize",value = "每页数量",required = false,dataType = "int")
    })
    @GetMapping("expert")
    PageInfo<UserDto> getLists(@RequestParam(value = "pageNum",defaultValue = "1") Integer pageNum, @RequestParam(value = "pageSize",defaultValue = "10") Integer pageSize){
        return userService.getList(pageNum,pageSize);
    }

    /**
     * 管理员获取某一用户的信息
     * @param userId
     * @return
     */
    @ApiOperation(value = "管理员或专家获取某一用户的信息",notes = "获取某一用户的信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "userId", value = "用户id", required = true, dataType = "int")
    })
    @GetMapping("expert/one")
    User getOneUserbyAdmin(@RequestParam("userId")Integer userId){
        return userService.getOneUserByAdmin(userId);
    }

    /**
     * 用户获取个人信息
     * @return
     */
    @ApiOperation(value = "用户获取个人信息",notes = "用户获取个人信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @GetMapping("user/one")
    User getOneUserbyUser(){
        return userService.getOneUserByUser();
    }

    @ApiOperation(value = "管理员或专家获取某一用户的所有日常投放数据",notes = "获取所有日常投放数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "username", value = "用户username", required = true, dataType = "String")
    })
    @RequestMapping(value = "expert/throw",method = RequestMethod.GET)
    PageVO<DailyThrow> getAllDailyThrow(PageQO pageQO,@RequestParam String username){
        return dailyThrowService.getAllDailyThrowByUsername(pageQO,username);
    }

    @ApiOperation(value = "管理员或专家根据日期获取所有日常投放数据",notes = "根据日期获取所有日常投放数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "startDate", value = "开始日期", required = true, dataType = "String"),
            @ApiImplicitParam(name = "endDate", value = "结束日期", required = true, dataType = "String"),
    })
    @RequestMapping(value = "expert/throw/date",method = RequestMethod.GET)
    PageVO<DailyThrow> getDailyThrowByDate(@RequestParam String startDate,@RequestParam String endDate,PageQO pageQO,@RequestParam String username){
        return dailyThrowService.getDailyThrowByDateByUsername(pageQO, startDate, endDate,username);
    }

    /**
     * 重置密码
     * @param request HttpServlet 请求
     * @param resetPassword 密码对象
     * @return 带有token的用户信息
     */
    @ApiOperation(value = "重置密码",notes = "重置密码")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "resetPassword", value = "密码对对象", required = true, dataType = "ResetPassword")
    })
    @PutMapping("user/resetpassword")
    Boolean resetPassword(HttpServletRequest request, @RequestBody ResetPassword resetPassword,HttpServletResponse response){
        return userService.resetPassword(request,resetPassword,response);
    }

    /**
     * 新增用户信息
     * @param userDO
     * @return
     */
    @ApiOperation(value = "新增用户信息",notes = "管理员增加用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "userDO", value = "用户信息", required = true, dataType = "User")
    })
    @PostMapping("admin/add")
    User addUser(@RequestBody User userDO){
        return userService.addUser(userDO);
    }

    /**
     *更新用户信息
     * @param userDO
     * @return
     */
    @ApiOperation(value = "更新用户信息",notes = "用户更新个人信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "userDO", value = "用户信息", required = true, dataType = "User")
    })
    @PutMapping("user/resetinfo")
    User resetUserInfo( @RequestBody User userDO){
        return userService.resetInfo(userDO);
    }

    /**
     * 管理员删除用户
     * @param userId
     * @return
     */
    @ApiOperation(value = "管理员删除用户",notes = "管理员删除用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String"),
            @ApiImplicitParam(name = "userId", value = "用户id", required = true, dataType = "int")
    })
    @DeleteMapping("admin/{userId}")
    Boolean deleteUserInfo(@PathVariable Integer userId){
        return userService.deleteUserInfo(userId);
    }


    @ApiOperation(value = "获取所有角色",notes = "获取所有角色")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
                })
    @GetMapping("/roles")
    List<Role> getRoles(){
        return userService.getAllRoles();
    }

}

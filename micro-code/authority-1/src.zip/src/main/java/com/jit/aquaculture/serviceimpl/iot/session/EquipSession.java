package com.jit.aquaculture.serviceimpl.iot.session;

import com.jit.aquaculture.domain.iot.EquipDO;
import lombok.Data;

import java.util.Date;

@Data
public class EquipSession{
    private int id;
    private String type;
    private String defname;

    private int termid;
    private int addr;
    private int road;

    private int cellid;
    private int status; //当前状态
    private Date time;

    public EquipSession(EquipDO eq){
        id = eq.getId();
        type = eq.getType();
        defname = eq.getDefname();
        termid = eq.getTermid();
        addr = eq.getAddr();
        road = eq.getRoad();
        cellid = eq.getCellid();
        status = eq.getStatus();
        time = new Date();
    }
}

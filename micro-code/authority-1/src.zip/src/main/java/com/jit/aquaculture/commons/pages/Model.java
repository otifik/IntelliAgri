package com.jit.aquaculture.commons.pages;

import java.io.Serializable;

public interface Model extends Serializable {
}

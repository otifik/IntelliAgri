package com.jit.aquaculture.transport;

/**
 * 这个类演示了文档注释
 * @author Ayan Amhed
 * @version 1.2
 */
public class TransGate {

    //report 消息队列，批量入库

    //query、control实时消息，直接处理
}

package com.jit.aquaculture.config.iot;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class AgriCellType {
    int id;
    String type;
    List<String> products;
    String desc;
}

package com.jit.aquaculture.config.iot;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.jit.aquaculture.commons.util.JacksonUtils;
import com.jit.aquaculture.commons.util.ReadFileUtils;
import lombok.Data;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import lombok.extern.log4j.Log4j2;

import java.io.*;
import java.util.*;

/**
 * @packageName: com.jit.iot.utils.hardware
 * @className: JsonUtils
 * @Description:
 * @author: xxz
 * @date: 2019/7/26 21:16
 */
@Data
@Log4j2
@Configuration
public class SensorCmdCfg {
    public List<SensorCmd<SensorValue>> sensorList;
    public List<RelayCtlCmd> relaylist;
    public List<EquipType> equiplist;
    public List<TermType> termlist;
    public List<AgriCellType> cellist;
    private StringBuilder all;
//
//    @Value(value = "classpath:sensor_type.json")
//    private Resource sensorRes;
//
//    @Value(value = "classpath:dmaCtl.json")
//    private Resource dmaRes;
//
//    @Value(value = "classpath:equipment_type.json")
//    private Resource eqipRes;

    public SensorCmdCfg() {
        all = new StringBuilder();
        sensorList = new ArrayList();
        relaylist = new ArrayList();
        equiplist = new ArrayList();
        termlist = new ArrayList<>();
        cellist = new ArrayList<>();
        initCfgFromFile();
    }

    //查询所有的厂家
    public List<String> getManus(){
        List<String> manus = new ArrayList<>();
        Iterator<TermType> itor = termlist.iterator();
        while(itor.hasNext()){
            TermType term = itor.next();
            manus.add(term.getManu());
        }
        return manus;
    }

    //查询某厂家下所有的终端产品
    public List<String> getManuProducts(String manu){
        Iterator<TermType> itor = termlist.iterator();
        while(itor.hasNext()){
            TermType term = itor.next();
            if(term.getManu().equals(manu)){
                return term.getProducts();
            }
        }
        return null;
    }

    public List<String> getCellType(){
        List<String> ctypelist = new ArrayList<>();
        Iterator<AgriCellType> itor = cellist.iterator();
        while(itor.hasNext()){
            AgriCellType cell = itor.next();
            ctypelist.add(cell.getType());
        }
        return ctypelist;
    }

    public List<String> getAgriProducts(String ctype){
        Iterator<AgriCellType> itor = cellist.iterator();
        while(itor.hasNext()){
            AgriCellType cell = itor.next();
            if(cell.getType().equals(ctype)){
                return cell.getProducts();
            }
        }
        return null;
    }
    /*private static SensorCmdCfg instance;

    public static SensorCmdCfg getInstance(){
        if(instance == null){
            instance = new SensorCmdCfg();
        }
        return instance;
    }*/


    private void initCfgFromFile(){
        InputStream stream = null;
        sensorList.clear();
        all.setLength(0);
        all = readFile("json/sensor_type.json");
//        all = ReadFileUtils.readFile("json/sensor_type.json");
//        all = readRes(sensorRes);
//        stream = getClass().getClassLoader().getResourceAsStream("/json/sensor_type.json");
//        all = ReadFileUtils.readFileStream(stream);
        if(all!=null){
            sensorList = JacksonUtils.readValue(all.toString(), new TypeReference<List<SensorCmd<SensorValue>>>() { });
        }

        relaylist.clear();
        all.setLength(0);
        all = readFile("json/dmaCtl.json");
//        all = ReadFileUtils.readFile("json/dmaCtl.json");
//        all = readRes(dmaRes);
//        stream = getClass().getClassLoader().getResourceAsStream("/json/dmaCtl.json");
//        all = ReadFileUtils.readFileStream(stream);
        if(all!=null){
            relaylist = JacksonUtils.readValue(all.toString(), new TypeReference<List<RelayCtlCmd>>() { });
        }

        equiplist.clear();
        all.setLength(0);
//        all = readRes(eqipRes);
        all = readFile("json/equipment_type.json");
//        all = ReadFileUtils.readFile("json/equipment_type.json");
//        stream = getClass().getClassLoader().getResourceAsStream("/json/equipment_type.json");
//        all = ReadFileUtils.readFileStream(stream);
        if(all!=null){
            equiplist = JacksonUtils.readValue(all.toString(), new TypeReference<List<EquipType>>() { });
        }

        termlist.clear();
        all.setLength(0);
        all = readFile("json/term_type.json");
        if(all!=null){
            termlist = JacksonUtils.readValue(all.toString(), new TypeReference<List<TermType>>() { });
        }

        cellist.clear();
        all.setLength(0);
        all = readFile("json/cell_type.json");
        if(all!=null){
            cellist = JacksonUtils.readValue(all.toString(), new TypeReference<List<AgriCellType>>() { });
        }
    }



    private StringBuilder readFile(String filename) {
        //读取到静态资源文件
//        Resource resource = new ClassPathResource(filename);
        File file = null;
        StringBuilder all = new StringBuilder();
        try {
//            file = resource.getFile();
            //使用io读出数据
            BufferedReader br = new BufferedReader(new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(filename)));
            String str = null;
            while((str = br.readLine()) != null){
                all.append(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return all;
    }

    private StringBuilder readRes(Resource resource) {
        //读取到静态资源文件
        File file = null;
        StringBuilder all = new StringBuilder();
        try {
            file = resource.getFile();
            //使用io读出数据
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String str = null;
            while((str = br.readLine()) != null){
                all.append(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return all;
    }

}

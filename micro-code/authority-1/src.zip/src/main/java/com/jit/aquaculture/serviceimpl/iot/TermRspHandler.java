package com.jit.aquaculture.serviceimpl.iot;

public interface TermRspHandler {
    void execute();
    void timeout();
}

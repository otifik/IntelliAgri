package com.jit.aquaculture.config.iot;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class TermType {
    int id;
    String type;
    String manu;
    List<String> products;
    String desc;
}

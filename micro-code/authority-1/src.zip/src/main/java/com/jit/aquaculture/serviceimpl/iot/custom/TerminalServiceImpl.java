package com.jit.aquaculture.serviceimpl.iot.custom;

import com.baomidou.mybatisplus.mapper.EntityWrapper;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.jit.aquaculture.commons.pages.PageQO;
import com.jit.aquaculture.commons.pages.PageVO;
import com.jit.aquaculture.domain.iot.TermDO;
import com.jit.aquaculture.mapper.iot.TermDAO;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.SelectKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class TerminalServiceImpl {
    @Autowired
    TermDAO termDAO;

    /**
     * 新增用户终端
     * @param type   终端类型
     * @param name   终端名字
     * @param deveui 串号
     * @param user   终端归属用户
     * @return
     */
    @SelectKey(statement="select LAST_INSERT_ID()", keyProperty="id", before=false, resultType=int.class)
    public TermDO addTerm(int type, String deveui, String name, String user){
        //需要判断是否有权限操作
        String opter = SecurityContextHolder.getContext().getAuthentication().getName();
        log.debug("用户{}新增{}类型终端, deveui:{}, 终端归属:{}", opter, type, deveui, user);
        TermDO term = getTerm(type, deveui, opter, name);
        if(term!=null){
            log.error("终端ID:"+term.getId()+" 已存在");
            return null;
        }
        term =  new TermDO(type, deveui,user, name);
        int ret = termDAO.insert(term);
        if (ret < 0) {
            log.error("添加终端type:{}, name:{}失败", type,name);
            return null;
        } else {
            return term;
        }
    }

    /**
     * 列出系统下所有终端
     * @return
     */
    public PageVO<TermDO> listAllTerms(PageQO pageQO){
        Page<TermDO> page = PageHelper.startPage(pageQO.getPageNum(),pageQO.getPageSize());
        List<TermDO> termDOS = termDAO.selectList(new EntityWrapper<TermDO>());
        return PageVO.build(page);
//        return termDAO.selectList(new EntityWrapper<TermDO>());
    }

    /**
     * 查询用户终端
     * @param usrname 用户名称
     * @return
     */
    public PageVO<TermDO> listTermsByUsr(PageQO pageQO, String usrname){
        Page<TermDO> page = PageHelper.startPage(pageQO.getPageNum(),pageQO.getPageSize());
        List<TermDO> termDOS =  termDAO.selectList(new EntityWrapper<TermDO>().eq("username", usrname));
        return PageVO.build(page);
    }

    public TermDO loginTerm(int type, int termid, String deveui){
        return updateTermSta(type, termid ,deveui,1);
    }

    public TermDO logoutTerm(int type, int termid, String deveui){
        return updateTermSta(type, termid, deveui, 0);
    }


    /**
     * 根据用户终端name和deveui获取终端对象
     * @param type   终端类型
     * @param usrname name   终端名字、用户名字
     * @param deveui 串号
     * @return
     */
    private TermDO getTerm(int type, String deveui, String usrname, String name){
        List<TermDO> termlist;
        if((type==2||type==3) && deveui!=null)
            termlist = termDAO.selectList(new EntityWrapper<TermDO>().eq("deveui", deveui).last("LIMIT 1"));
        else
            termlist = termDAO.selectList(new EntityWrapper<TermDO>().eq("name", name).eq("username", usrname).last("LIMIT 1"));
        if(termlist!=null && !termlist.isEmpty()){
            return termlist.get(0);
        }else{
            return null;
        }
    }

    /**
     * 根据ID和deveui获取终端对象
     * @param type   终端类型
     * @param tid    终端ID
     * @param deveui 串号
     * @return
     */
    public TermDO getTermById(int type, int tid, String deveui){
        List<TermDO> termlist;
        if(type==1){
            return termDAO.selectById(tid);
        }
        if((type==2||type==3) && deveui!=null) {
            termlist = termDAO.selectList(new EntityWrapper<TermDO>().eq("deveui", deveui).last("LIMIT 1"));
            if (termlist != null && !termlist.isEmpty()) {
                return termlist.get(0);
            }
        }
        return null;
    }

    /**
     * 根据ID和deveui更新终端在线状态
     * @param type   终端类型
     * @param termid 终端ID
     * @param deveui 串号
     * @param sta    更新状态
     * @return
     */
    private TermDO updateTermSta(int type, int termid, String deveui, int sta){
        TermDO term = getTermById(type, termid, deveui);
        if(term == null){
            log.error("终端type:{}, ID:{}, deveui:{}不存在", type, termid, deveui);
            return null;
        }
        term.setStatus(sta);
        int ret = termDAO.updateById(term);
        if (ret < 0) {
            log.error("更新终端tid:{} deveui:{} 状态status:{} 失败", termid, deveui, term.getStatus());
            return null;
        } else {
            return term;
        }
    }
}

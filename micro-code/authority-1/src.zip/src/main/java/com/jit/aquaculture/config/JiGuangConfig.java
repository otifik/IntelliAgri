package com.jit.aquaculture.config;

public class JiGuangConfig {

    public static final  String APP_KEY = "24fc617a9ae3cf61dbd0b5c7";
    public static final String MASTER_SECRET = "0a7f06e5f68fc1341f991ac3";
}

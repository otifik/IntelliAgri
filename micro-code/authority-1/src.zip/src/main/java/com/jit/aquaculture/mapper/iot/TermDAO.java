package com.jit.aquaculture.mapper.iot;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import com.jit.aquaculture.domain.iot.TermDO;
import org.springframework.stereotype.Repository;

@Repository
public interface TermDAO extends BaseMapper<TermDO> {
}

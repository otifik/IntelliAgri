package com.jit.aquaculture.serviceimpl.iot.prepare;

/**
 * 消息规范统一成平台上的标准Bean
 * @author xsy
 * @version 0.1
 */
public class MsgUniform {

}

package com.jit.aquaculture.serviceimpl.iot;

public class DataExchange {
    //数据交换
    /* 数据转发 */

}

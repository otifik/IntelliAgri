package com.jit.aquaculture.serviceinterface.user;



import com.github.pagehelper.PageInfo;
import com.jit.aquaculture.domain.user.Role;
import com.jit.aquaculture.domain.user.User;
import com.jit.aquaculture.domain.user.UserRole;
import com.jit.aquaculture.dto.ResetPassword;
import com.jit.aquaculture.dto.UserDto;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface UserService {
    PageInfo<UserDto> getList(Integer pageNum, Integer pageSize);

    User getOneUserByAdmin(Integer userId);
    User getOneUserByUser();

    Boolean resetPassword(HttpServletRequest request, ResetPassword resetPassword,HttpServletResponse response);

    User addUser(User userDO);

    User resetInfo(User userDO);

    Boolean deleteUserInfo(Integer userId);

    List<Role> getAllRoles();

}

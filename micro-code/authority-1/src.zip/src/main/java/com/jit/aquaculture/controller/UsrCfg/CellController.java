package com.jit.aquaculture.controller.UsrCfg;

import com.jit.aquaculture.commons.pages.PageQO;
import com.jit.aquaculture.commons.pages.PageVO;
import com.jit.aquaculture.config.iot.SensorCmdCfg;
import com.jit.aquaculture.domain.iot.CellDO;
import com.jit.aquaculture.responseResult.result.ResponseResult;
import com.jit.aquaculture.serviceimpl.iot.custom.CellServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;

/**
 * @packageName: com.jit.iot.controller
 * @className: CellService
 * @author: xxz
 * @date: 2019/7/25 10:05
 */

@RestController
@CrossOrigin
@RequestMapping(value = "/celldef")
@Api(description = "生产单元配置接口")
@ResponseResult
public class CellController {
    @Resource
    CellServiceImpl cellService;
    @Autowired
    SensorCmdCfg cmdCfg;

    @ApiOperation(value = "查询农业生产单元类型(农业生产场景)" ,  notes="水产/种植/养殖/大田")
    @RequestMapping(value = "/listCellTypes", method = RequestMethod.GET)
    public List<String> listCellTypes() {
        return cmdCfg.getCellType();
    }

    @ApiOperation(value = "查询该生产单元下的农产品" ,  notes="种植养殖品种")
    @RequestMapping(value = "/listAgriProducts", method = RequestMethod.GET)
    public List<String> listAgriProducts( @RequestParam(value = "celltype") String celltype) {
        return cmdCfg.getAgriProducts(celltype);
    }

    //用户新增生产单元
    @ApiOperation(value = "新增生产单元" ,  notes="用户新增生产单元")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/addCell", method = RequestMethod.POST)
    public Boolean addCell(@RequestParam(value = "length") float length,
                           @RequestParam(value = "width") float width,
                           @RequestParam(value = "longitude") double longitude,
                           @RequestParam(value = "latitude") double latitude,
                           @RequestParam(value = "type") String type,
                           @RequestParam(value = "prod") String prod,
                           @RequestParam(value = "cell_name") String cell_name,
                           @RequestParam(value = "user_name") String user_name
                           ) throws Exception{
        //调用service
        return cellService.add_cell(length, width, longitude, latitude, type, prod, cell_name, user_name);
    }

    //查询用户生产单元信息
    @ApiOperation(value = "查询用户的所有生产单元" ,  notes="列出用户的所有生产单元")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/listUserCells", method = RequestMethod.GET)
    public PageVO<CellDO> listUserCells(@RequestParam(value = "username") String username,
                                        PageQO pageQO) {
        return cellService.getUsrCells(pageQO, username);
    }

    //更新生产单元
    @ApiOperation(value = "更新生产单元" ,  notes="用户更新生产单元")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/updateCell", method = RequestMethod.POST)
    public Boolean updateCell(
                           @RequestParam(value = "id") int id,
                           @RequestParam(value = "length") float length,
                           @RequestParam(value = "width") float width,
                           @RequestParam(value = "longitude") double longitude,
                           @RequestParam(value = "latitude") double latitude,
                           @RequestParam(value = "type") String type,
                           @RequestParam(value = "prod") String prod,
                           @RequestParam(value = "cell_name") String cell_name,
                           @RequestParam(value = "user_name") String user_name
    ) throws Exception{
        //调用service
        return cellService.update_cell(id, length, width, longitude, latitude, type, prod, cell_name, user_name);
    }

    //删除生产单元
    @ApiOperation(value = "删除具体的生产单元" ,  notes="删除ID对应的生产单元")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/delCell", method = RequestMethod.DELETE)
    public Boolean delCell(@RequestParam(value = "id") int id) {
        return cellService.delete_cell(id);
    }
}

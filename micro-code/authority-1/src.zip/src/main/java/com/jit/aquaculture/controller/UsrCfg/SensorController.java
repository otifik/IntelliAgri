package com.jit.aquaculture.controller.UsrCfg;


import com.jit.aquaculture.config.iot.SensorCmdCfg;
import com.jit.aquaculture.domain.iot.SensorDO;
import com.jit.aquaculture.responseResult.result.ResponseResult;
import com.jit.aquaculture.serviceimpl.iot.custom.SensorDefServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @packageName: com.jit.iot.controller
 * @className: SensorCroller
 * @Description:
 * @author: xxz
 * @date: 2019/7/25 10:05
 */

@RestController
@CrossOrigin
@RequestMapping(value = "/sensordef")
@Api(description = "传感器配置接口")
@ResponseResult
public class SensorController {
    @Autowired
    SensorCmdCfg cmdCfg;

    @Autowired
    SensorDefServiceImpl sensorService;

    //刷新485传感器类型
    @ApiOperation(value = "刷新485传感器类型" ,  notes="重新读取传感器类型的xml文件")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/sensorRefresh", method = RequestMethod.GET)
    public void sensor_refresh() {
        cmdCfg.getSensorList();
    }


    //用户查看可以添加的传感器类型
    @ApiOperation(value = "查询所有485传感器类型" ,  notes="列出所有支持的485传感器类型")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/listSensorType", method = RequestMethod.GET)
    public List<String> listSensorType() {
       cmdCfg.getSensorList();
       return sensorService.listSensorType();
    }


    //生产单元新增传感器
    @ApiOperation(value = "新增485传感器" ,  notes="在生产单元下新增485传感器")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/addSensor", method = RequestMethod.POST)
    public Boolean addSensor(@RequestParam(value = "cell_id") int cell_id,
                             @RequestParam(value = "term_id") int term_id,
                             @RequestParam(value = "sensor_type") String sensor_type,
                             @RequestParam(value = "addr") int addr,
                             @RequestParam(value = "sensor_name") String sensor_name) throws Exception{
        return sensorService.addSensor(cell_id, term_id, sensor_type, addr,  sensor_name);
    }

    //用户查询传感器信息
    @ApiOperation(value = "查询传感器" ,  notes="列出生产单元下的所有传感器")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "该参数值（value='Bearer {token}'）在request header中", paramType ="header", required = true, dataType = "String")
    })
    @RequestMapping(value = "/cellSensors", method = RequestMethod.GET)
    public List<SensorDO> cellSensors(@RequestParam(value = "cell_id") int cell_id) {
        return sensorService.cellSensors(cell_id);
    }


}

package com.jit.aquaculture.mapper.iot;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.jit.aquaculture.domain.iot.EquipActionDO;
import org.apache.ibatis.annotations.Insert;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipmentActionDAO extends BaseMapper<EquipActionDO> {
}
